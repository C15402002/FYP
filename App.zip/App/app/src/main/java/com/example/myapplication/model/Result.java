package com.example.myapplication.model;

class Result {
    public String message_id;
}
