package com.example.myapplication.view;

import android.view.View;

public interface ProductClickedListener {
    void onClick(View v, int pos, boolean isLongClicked);


}
