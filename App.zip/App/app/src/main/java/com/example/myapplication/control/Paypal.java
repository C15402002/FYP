package com.example.myapplication.control;

public class Paypal {
    public static final String paypal_ID = "AcWbZVQ6Cvl0SwaVRxsi5Bs7UK-y_9dbIgwBd_wWXOELQF-HvS-dTkFxZh2hbsGj40svWxa0PXJJGOe0";

}
